"""Generate too-st shorturl."""
__version__ = "0.1.0"
from .too_st import too_st
from .check_url import check_url

__all__ = ("too_st", "check_url")
